# script3.py
def main():
    print("Este es el script 3")

if __name__ == "__main__":
    main()

