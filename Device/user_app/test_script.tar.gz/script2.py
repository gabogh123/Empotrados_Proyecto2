# script2.py
def main():
    print("Este es el script 2")

if __name__ == "__main__":
    main()

