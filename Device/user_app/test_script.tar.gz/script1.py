# script1.py
def main():
    print("Este es el script 1")

if __name__ == "__main__":
    main()

